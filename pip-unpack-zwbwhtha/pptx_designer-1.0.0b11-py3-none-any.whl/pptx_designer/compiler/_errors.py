class SVGCompileError(Exception):
    pass
